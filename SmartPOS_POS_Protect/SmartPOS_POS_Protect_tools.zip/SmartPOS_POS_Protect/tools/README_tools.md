# SmartPOS_POS_Protect tools

This folder contains helper scripts to initialize Windows diagnostics for the POS Protect agent.

## Scripts
- `evt_enable.ps1` — enable and configure Event Logs (System/Application size & retention, PrintService/Operational).
- `wer_enable.ps1` — enable Windows Error Reporting + LocalDumps (mini dumps, retention).

## Usage
Open **PowerShell as Administrator** and run:

```powershell
Set-Location <repo-root>\SmartPOS_POS_Protect\tools
.\evt_enable.ps1
.\wer_enable.ps1
```

These scripts are **idempotent** and safe to re-run.
